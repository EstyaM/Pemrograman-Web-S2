<?= $this->extend('layout/template'); ?>

<h2 class="mt-2">Detail Device</h2>

<a href="/device">Back to Home</a>

<?= $this->endSection(); ?>